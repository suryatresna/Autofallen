
 
 
 
 
 <!--<div id="tabs">
	<ul>
		<li><a href="#tabs-1">Sub Menu</a></li>
		
	</ul>
	<div id="tabs-1">
		<p>Morbi tincidunt, dui sit amet facilisis feugiat, odio metus gravida ante, ut pharetra massa metus id nunc. Duis scelerisque molestie turpis. Sed fringilla, massa eget luctus malesuada, metus eros molestie lectus, ut tempus eros massa ut dolor. Aenean aliquet fringilla sem. Suspendisse sed ligula in ligula suscipit aliquam. Praesent in eros vestibulum mi adipiscing adipiscing. Morbi facilisis. Curabitur ornare consequat nunc. Aenean vel metus. Ut posuere viverra nulla. Aliquam erat volutpat. Pellentesque convallis. Maecenas feugiat, tellus pellentesque pretium posuere, felis lorem euismod felis, eu ornare leo nisi vel felis. Mauris consectetur tortor et purus.</p>
        <p>
		Mauris mauris ante, blandit et, ultrices a, suscipit eget, quam. Integer
		ut neque. Vivamus nisi metus, molestie vel, gravida in, condimentum sit
		amet, nunc. Nam a nibh. Donec suscipit eros. Nam mi. Proin viverra leo ut
		odio. Curabitur malesuada. Vestibulum a velit eu ante scelerisque vulputate.
		</p>
	</div>
</div>
 
 <div id="right-bar">
 	<ul>
    <h3>Title Menu</h3>
    <li>Luim Tre</li>
    <li>Luim Tre</li>
    <li>Luim Tre</li>
    <li>Luim Tre</li>
    </ul>
    <ul>
    <h3>Title Menu</h3>
    <li>Luim Tre</li>
    <li>Luim Tre</li>
    <li>Luim Tre</li>
    <li>Luim Tre</li>
    </ul>
 </div>-->
 
 
 </div>
 
 
 
 
 <!-- FOOTER SET -->
 <div id="footer">
  <? echo FOOTER.' @ '.AUTHOR.'. '.YEAR_IN ?>
 </div>
 
</div>

</body>
</html>