<?
if(!isset($_GET['tb']))
{
		
}
?>